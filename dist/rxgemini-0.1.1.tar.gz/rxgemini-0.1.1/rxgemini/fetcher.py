"""Data fetcher module for rxgemini"""

import functools
import inspect


def data_fetcher(func):
    @functools.wraps
    def wrapper_fetcher(*args, **kwargs):
        obj_name = func.__name__
        src_file = inspect.getfile(func)
