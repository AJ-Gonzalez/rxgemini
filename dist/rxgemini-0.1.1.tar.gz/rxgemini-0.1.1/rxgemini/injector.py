"""Injection module for RX Gemini"""
